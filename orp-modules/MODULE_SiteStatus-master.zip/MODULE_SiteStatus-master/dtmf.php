<?php
$sub_subcommands = 'No DTMF codes are available for this module';
?>